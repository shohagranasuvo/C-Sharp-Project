﻿namespace Diagnostic
{
    partial class UcPatient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroRadioButton3 = new MetroFramework.Controls.MetroRadioButton();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.metroDateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.metroRadioButton2 = new MetroFramework.Controls.MetroRadioButton();
            this.txtPatientAddress = new MetroFramework.Controls.MetroTextBox();
            this.metroRadioButton1 = new MetroFramework.Controls.MetroRadioButton();
            this.txtPatientEmail = new MetroFramework.Controls.MetroTextBox();
            this.txtPatientPhone = new MetroFramework.Controls.MetroTextBox();
            this.txtPatientName = new MetroFramework.Controls.MetroTextBox();
            this.txtPatientId = new MetroFramework.Controls.MetroTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPatientId = new System.Windows.Forms.Label();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.btnUpdate = new MetroFramework.Controls.MetroButton();
            this.btnClear = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // metroRadioButton3
            // 
            this.metroRadioButton3.AutoSize = true;
            this.metroRadioButton3.Location = new System.Drawing.Point(526, 447);
            this.metroRadioButton3.Margin = new System.Windows.Forms.Padding(6);
            this.metroRadioButton3.Name = "metroRadioButton3";
            this.metroRadioButton3.Size = new System.Drawing.Size(58, 15);
            this.metroRadioButton3.TabIndex = 45;
            this.metroRadioButton3.Text = "Others";
            this.metroRadioButton3.UseSelectable = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(968, 283);
            this.btnSave.Margin = new System.Windows.Forms.Padding(6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(150, 79);
            this.btnSave.TabIndex = 44;
            this.btnSave.Text = "Save";
            this.btnSave.UseSelectable = true;
            // 
            // metroDateTime1
            // 
            this.metroDateTime1.Location = new System.Drawing.Point(374, 501);
            this.metroDateTime1.Margin = new System.Windows.Forms.Padding(6);
            this.metroDateTime1.MinimumSize = new System.Drawing.Size(0, 29);
            this.metroDateTime1.Name = "metroDateTime1";
            this.metroDateTime1.Size = new System.Drawing.Size(320, 31);
            this.metroDateTime1.TabIndex = 43;
            // 
            // metroRadioButton2
            // 
            this.metroRadioButton2.AutoSize = true;
            this.metroRadioButton2.Location = new System.Drawing.Point(392, 447);
            this.metroRadioButton2.Margin = new System.Windows.Forms.Padding(6);
            this.metroRadioButton2.Name = "metroRadioButton2";
            this.metroRadioButton2.Size = new System.Drawing.Size(61, 15);
            this.metroRadioButton2.TabIndex = 42;
            this.metroRadioButton2.Text = "Female";
            this.metroRadioButton2.UseSelectable = true;
            // 
            // txtPatientAddress
            // 
            // 
            // 
            // 
            this.txtPatientAddress.CustomButton.Image = null;
            this.txtPatientAddress.CustomButton.Location = new System.Drawing.Point(248, 2);
            this.txtPatientAddress.CustomButton.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientAddress.CustomButton.Name = "";
            this.txtPatientAddress.CustomButton.Size = new System.Drawing.Size(97, 97);
            this.txtPatientAddress.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPatientAddress.CustomButton.TabIndex = 1;
            this.txtPatientAddress.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPatientAddress.CustomButton.UseSelectable = true;
            this.txtPatientAddress.CustomButton.Visible = false;
            this.txtPatientAddress.Lines = new string[] {
        "Address"};
            this.txtPatientAddress.Location = new System.Drawing.Point(770, 455);
            this.txtPatientAddress.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientAddress.MaxLength = 32767;
            this.txtPatientAddress.Multiline = true;
            this.txtPatientAddress.Name = "txtPatientAddress";
            this.txtPatientAddress.PasswordChar = '\0';
            this.txtPatientAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPatientAddress.SelectedText = "";
            this.txtPatientAddress.SelectionLength = 0;
            this.txtPatientAddress.SelectionStart = 0;
            this.txtPatientAddress.ShortcutsEnabled = true;
            this.txtPatientAddress.Size = new System.Drawing.Size(348, 102);
            this.txtPatientAddress.TabIndex = 41;
            this.txtPatientAddress.Text = "Address";
            this.txtPatientAddress.UseSelectable = true;
            this.txtPatientAddress.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPatientAddress.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroRadioButton1
            // 
            this.metroRadioButton1.AutoSize = true;
            this.metroRadioButton1.Location = new System.Drawing.Point(282, 447);
            this.metroRadioButton1.Margin = new System.Windows.Forms.Padding(6);
            this.metroRadioButton1.Name = "metroRadioButton1";
            this.metroRadioButton1.Size = new System.Drawing.Size(49, 15);
            this.metroRadioButton1.TabIndex = 40;
            this.metroRadioButton1.Text = "Male";
            this.metroRadioButton1.UseSelectable = true;
            // 
            // txtPatientEmail
            // 
            // 
            // 
            // 
            this.txtPatientEmail.CustomButton.Image = null;
            this.txtPatientEmail.CustomButton.Location = new System.Drawing.Point(200, 2);
            this.txtPatientEmail.CustomButton.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientEmail.CustomButton.Name = "";
            this.txtPatientEmail.CustomButton.Size = new System.Drawing.Size(47, 47);
            this.txtPatientEmail.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPatientEmail.CustomButton.TabIndex = 1;
            this.txtPatientEmail.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPatientEmail.CustomButton.UseSelectable = true;
            this.txtPatientEmail.CustomButton.Visible = false;
            this.txtPatientEmail.Lines = new string[] {
        "example@gmail.com"};
            this.txtPatientEmail.Location = new System.Drawing.Point(286, 358);
            this.txtPatientEmail.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientEmail.MaxLength = 32767;
            this.txtPatientEmail.Name = "txtPatientEmail";
            this.txtPatientEmail.PasswordChar = '\0';
            this.txtPatientEmail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPatientEmail.SelectedText = "";
            this.txtPatientEmail.SelectionLength = 0;
            this.txtPatientEmail.SelectionStart = 0;
            this.txtPatientEmail.ShortcutsEnabled = true;
            this.txtPatientEmail.Size = new System.Drawing.Size(250, 52);
            this.txtPatientEmail.TabIndex = 39;
            this.txtPatientEmail.Text = "example@gmail.com";
            this.txtPatientEmail.UseSelectable = true;
            this.txtPatientEmail.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPatientEmail.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPatientPhone
            // 
            // 
            // 
            // 
            this.txtPatientPhone.CustomButton.Image = null;
            this.txtPatientPhone.CustomButton.Location = new System.Drawing.Point(200, 2);
            this.txtPatientPhone.CustomButton.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientPhone.CustomButton.Name = "";
            this.txtPatientPhone.CustomButton.Size = new System.Drawing.Size(47, 47);
            this.txtPatientPhone.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPatientPhone.CustomButton.TabIndex = 1;
            this.txtPatientPhone.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPatientPhone.CustomButton.UseSelectable = true;
            this.txtPatientPhone.CustomButton.Visible = false;
            this.txtPatientPhone.Lines = new string[] {
        "+8801XXX-XXXXXX"};
            this.txtPatientPhone.Location = new System.Drawing.Point(286, 283);
            this.txtPatientPhone.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientPhone.MaxLength = 32767;
            this.txtPatientPhone.Name = "txtPatientPhone";
            this.txtPatientPhone.PasswordChar = '\0';
            this.txtPatientPhone.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPatientPhone.SelectedText = "";
            this.txtPatientPhone.SelectionLength = 0;
            this.txtPatientPhone.SelectionStart = 0;
            this.txtPatientPhone.ShortcutsEnabled = true;
            this.txtPatientPhone.Size = new System.Drawing.Size(250, 52);
            this.txtPatientPhone.TabIndex = 38;
            this.txtPatientPhone.Text = "+8801XXX-XXXXXX";
            this.txtPatientPhone.UseSelectable = true;
            this.txtPatientPhone.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPatientPhone.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPatientName
            // 
            // 
            // 
            // 
            this.txtPatientName.CustomButton.Image = null;
            this.txtPatientName.CustomButton.Location = new System.Drawing.Point(200, 2);
            this.txtPatientName.CustomButton.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientName.CustomButton.Name = "";
            this.txtPatientName.CustomButton.Size = new System.Drawing.Size(47, 47);
            this.txtPatientName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPatientName.CustomButton.TabIndex = 1;
            this.txtPatientName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPatientName.CustomButton.UseSelectable = true;
            this.txtPatientName.CustomButton.Visible = false;
            this.txtPatientName.Lines = new string[] {
        "Mr. Bruce"};
            this.txtPatientName.Location = new System.Drawing.Point(286, 208);
            this.txtPatientName.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientName.MaxLength = 32767;
            this.txtPatientName.Name = "txtPatientName";
            this.txtPatientName.PasswordChar = '\0';
            this.txtPatientName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPatientName.SelectedText = "";
            this.txtPatientName.SelectionLength = 0;
            this.txtPatientName.SelectionStart = 0;
            this.txtPatientName.ShortcutsEnabled = true;
            this.txtPatientName.Size = new System.Drawing.Size(250, 52);
            this.txtPatientName.TabIndex = 37;
            this.txtPatientName.Text = "Mr. Bruce";
            this.txtPatientName.UseSelectable = true;
            this.txtPatientName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPatientName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPatientId
            // 
            // 
            // 
            // 
            this.txtPatientId.CustomButton.Image = null;
            this.txtPatientId.CustomButton.Location = new System.Drawing.Point(200, 2);
            this.txtPatientId.CustomButton.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientId.CustomButton.Name = "";
            this.txtPatientId.CustomButton.Size = new System.Drawing.Size(47, 47);
            this.txtPatientId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPatientId.CustomButton.TabIndex = 1;
            this.txtPatientId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPatientId.CustomButton.UseSelectable = true;
            this.txtPatientId.CustomButton.Visible = false;
            this.txtPatientId.Lines = new string[0];
            this.txtPatientId.Location = new System.Drawing.Point(286, 133);
            this.txtPatientId.Margin = new System.Windows.Forms.Padding(6);
            this.txtPatientId.MaxLength = 32767;
            this.txtPatientId.Name = "txtPatientId";
            this.txtPatientId.PasswordChar = '\0';
            this.txtPatientId.ReadOnly = true;
            this.txtPatientId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPatientId.SelectedText = "";
            this.txtPatientId.SelectionLength = 0;
            this.txtPatientId.SelectionStart = 0;
            this.txtPatientId.ShortcutsEnabled = true;
            this.txtPatientId.Size = new System.Drawing.Size(250, 52);
            this.txtPatientId.TabIndex = 36;
            this.txtPatientId.UseSelectable = true;
            this.txtPatientId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPatientId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(114, 358);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 43);
            this.label7.TabIndex = 35;
            this.label7.Text = "Email :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(762, 407);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 43);
            this.label6.TabIndex = 34;
            this.label6.Text = "Address :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(108, 433);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 43);
            this.label5.TabIndex = 33;
            this.label5.Text = "Sex :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(108, 508);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(257, 43);
            this.label3.TabIndex = 32;
            this.label3.Text = "Date of Birth :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(108, 283);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 43);
            this.label2.TabIndex = 31;
            this.label2.Text = "Phone :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(108, 208);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 43);
            this.label4.TabIndex = 30;
            this.label4.Text = "Name :";
            // 
            // lblPatientId
            // 
            this.lblPatientId.AutoSize = true;
            this.lblPatientId.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatientId.Location = new System.Drawing.Point(108, 133);
            this.lblPatientId.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPatientId.Name = "lblPatientId";
            this.lblPatientId.Size = new System.Drawing.Size(84, 43);
            this.lblPatientId.TabIndex = 29;
            this.lblPatientId.Text = "ID :";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(968, 158);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(150, 79);
            this.btnDelete.TabIndex = 28;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseSelectable = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(770, 283);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(6);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(150, 79);
            this.btnUpdate.TabIndex = 27;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseSelectable = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(770, 158);
            this.btnClear.Margin = new System.Windows.Forms.Padding(6);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(150, 79);
            this.btnClear.TabIndex = 26;
            this.btnClear.Text = "Clear";
            this.btnClear.UseSelectable = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(460, 562);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(320, 51);
            this.label1.TabIndex = 25;
            this.label1.Text = "**Patient List**";
            // 
            // UcPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroRadioButton3);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.metroDateTime1);
            this.Controls.Add(this.metroRadioButton2);
            this.Controls.Add(this.txtPatientAddress);
            this.Controls.Add(this.metroRadioButton1);
            this.Controls.Add(this.txtPatientEmail);
            this.Controls.Add(this.txtPatientPhone);
            this.Controls.Add(this.txtPatientName);
            this.Controls.Add(this.txtPatientId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblPatientId);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label1);
            this.Name = "UcPatient";
            this.Size = new System.Drawing.Size(1226, 747);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroRadioButton metroRadioButton3;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroDateTime metroDateTime1;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton2;
        private MetroFramework.Controls.MetroTextBox txtPatientAddress;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton1;
        private MetroFramework.Controls.MetroTextBox txtPatientEmail;
        private MetroFramework.Controls.MetroTextBox txtPatientPhone;
        private MetroFramework.Controls.MetroTextBox txtPatientName;
        private MetroFramework.Controls.MetroTextBox txtPatientId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblPatientId;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroButton btnUpdate;
        private MetroFramework.Controls.MetroButton btnClear;
        private System.Windows.Forms.Label label1;
    }
}
